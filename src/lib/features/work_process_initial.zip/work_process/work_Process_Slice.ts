// import {useState} from "react";
// import {
//     working_Process_Slider_Data_Interface
// } from "@/app/ui/career/ourWorkProcess/data/working_Process_Slider_Data_Interface";
// import workingProcessSliderData from "@/app/ui/career/ourWorkProcess/data/workingProcessSliderData";
//
//
// const [processes, set_processes] = useState<[] | working_Process_Slider_Data_Interface[]>(workingProcessSliderData);
// const [selected_Process, set_Selected_Process] = useState<working_Process_Slider_Data_Interface>(workingProcessSliderData[0]);



import { createSlice } from '@reduxjs/toolkit'
import type { PayloadAction } from '@reduxjs/toolkit'
import {RootState} from "@/lib/store";

interface workProcessState {
    value: number
}


const initialState: workProcessState = {
    value: 0,
}

export const workProcessSlice = createSlice({
    name: 'workProcess',

    initialState,
    reducers: {

    },
})

export const {

} = workProcessSlice.actions


export const selectCount = (state: RootState) => state.workProcess.value

export default workProcessSlice.reducer
